HamGrids Readme File 
Version 0.5 Beta Freeware
April 5, 2000


What HamGrids does
------------------
HamGrids will allow you to perform calculations with the popular
Maidenhead Grid Square system.  This grid system is used worldwide
by amateur radio operators for many aspects of ham radio.  Currently
in version 0.5 Beta, with HamGrids, you can Convert Latitude and
Longitude into a Grid Square, Convert a Grid Square into Latitude and
Longitude, calculate the distance between two Grid Squares, and 
calculatea beam heading between grid squares.

Requirements
------------
Windows 95/98/2000 or Windows NT 4.0 or higher
Visual Basic 5.0 Runtime DLL


Distribution
------------
You may freely distribute HamGrids, provided that it is unmodified from
its original form.  This means it must include the license agreement.


License
-------
See License.txt for license information.


Installation Notes
------------------
HamGrids is packaged in a self-extracting installation.  To install,
just execute the Setup.exe file and follow the instructions.  You
will be able to choose the destination directory.  The HamGrids
install will make a Programs group called "HamGrids".  To launch 
HamGrids, click on Start, Programs, HamGrids, then click the HamGrids
icon.  To uninstall HamGrids, open the windows control panel and
click on Add/Remove programs, locate HamGrids in the list of installed
programs, select it, and press Add/Remove.


Registration
------------
Since HamGrids is freeware, there is no need to register.  However, to
help us make Hamgrids a better product, your feedback is appreciated.
See the WinMorse home page at http://www.markbellamy.com/hamgrids/ for
info on how to leave feedback, Thanks!


Contact Info
------------
WinMorse Website: http://www.markbellamy.com/hamgrids/
Author's Email: mark@markbellamy.com

--The End--